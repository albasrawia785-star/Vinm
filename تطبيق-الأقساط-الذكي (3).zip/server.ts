import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Enable JSON parsing
  app.use(express.json({ limit: "50mb" }));

  // API proxy endpoint for downloading files from Telegram to bypass CORS
  app.get("/api/telegram/download", async (req, res) => {
    const { token, file_path } = req.query;
    if (!token || !file_path) {
      return res.status(400).json({ error: "Missing token or file_path parameter" });
    }

    try {
      const url = `https://api.telegram.org/file/bot${token}/${file_path}`;
      console.log(`[Proxy] Fetching file from Telegram: ${url}`);
      
      const response = await fetch(url);
      if (!response.ok) {
        return res.status(response.status).json({ error: `Failed to fetch file from Telegram: ${response.statusText}` });
      }

      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      res.setHeader("Content-Type", response.headers.get("content-type") || "application/json");
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.send(buffer);
    } catch (err: any) {
      console.error("[Proxy Error] Failed to download Telegram file:", err);
      res.status(500).json({ error: err.message || "Internal Server Error" });
    }
  });

  // API health route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
