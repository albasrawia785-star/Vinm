// يمكنك تعديل اسم المستخدم وكلمة المرور يدوياً من هذا الملف بكل سهولة
export const CREDENTIALS = {
  username: "ali",
  password: "0"
};
